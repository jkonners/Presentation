# **Julie Konners**

![Julie Headshot](https://media.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAAO9AAAAJGZkY2E3ODc0LTk3OWItNDQxYi04MDA2LTQyODEwMDc5NGZiYQ.jpg)

## **About Me**
------

My name is Julie Konners and I am from Fort Lauderdale, Florida. I am currently a senior at Indiana University majoring in public relations with a second concentration in tourism, hospitality, and event management. I am currently the Development and Alumni Relations Assistant in the Media School, where I assist with planning special events, including alumni receptions, awards ceremonies, board meetings and commencement receptions. I am also a member of the marketing committee for the Indiana University Dance Marathon, the nation’s second largest student-run philanthropy.

Connect with me on [LinkedIn](https://www.linkedin.com/in/juliekonners). 
[LinkedIn]:(https://www.linkedin.com/in/juliekonners) 

## **Things I like**
* Social Media
* The Hoosiers 
* Soccer 

## **My Favorite Quote**
------
>“What a wonderful thought it is that some of the best days of our lives haven’t happened yet.”

Anonymous 